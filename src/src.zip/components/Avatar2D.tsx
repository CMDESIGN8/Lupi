import { AvatarFace } from "./AvatarFace";
import type { AvatarAppearance, AvatarMood } from "../lib/avatarAppearance";
import { useMemo } from "react";
import { getItemVisual, type AvatarVisualSlot } from "../lib/avatarVisualRig";
import type { InventoryItem } from "../hooks/useAuraInventory";
import "./Avatar2D.css";

type Avatar2DProps = {
  items: InventoryItem[];
  level?: number;
  compact?: boolean;
  appearance?: AvatarAppearance;
  mood?: AvatarMood | "miss";
};

type AvatarLayer = {
  slot: string;
  item: InventoryItem | null;
};

const SLOT_ICONS: Record<string, string> = {
  accessory: "✦",
};

const SLOT_ORDER: AvatarVisualSlot[] = ["top", "bottom", "socks", "boots", "accessory"];

function AvatarItemImage({
  item,
  className,
}: {
  item: InventoryItem | null;
  className: string;
}) {
  if (!item) return null;

  const imageUrl =
    item.equippedImageUrl ?? item.imageUrl;

  if (!imageUrl) return null;

  return (
    <img
      className={className}
      src={imageUrl}
      alt=""
      draggable={false}
    />
  );
}

function hexToRgba(hex: string, alpha: number) {
  const clean = hex.replace("#", "");

  if (clean.length !== 6) {
    return `rgba(0,255,135,${alpha})`;
  }

  const r = parseInt(clean.slice(0, 2), 16);
  const g = parseInt(clean.slice(2, 4), 16);
  const b = parseInt(clean.slice(4, 6), 16);

  return `rgba(${r},${g},${b},${alpha})`;
}

function isShortSleeveTop(item: InventoryItem | null): boolean {
  if (!item) return false;
  const name = String(item.name ?? "").toLowerCase();
  if (/hoodie|campera|jacket|sweatshirt|buzo|long sleeve|manga larga|grind\s*tee/.test(name)) return false;
  return /farm\s*tee|remera|camiseta|t-shirt|tshirt|short sleeve|manga corta|\btee\b/.test(name);
}

export function Avatar2D({
  items,
  level = 1,
  compact = false,
  appearance,
  mood,
}: Avatar2DProps) {
  const equippedItems = useMemo(
    () => items.filter((item) => item.equipped),
    [items]
  );

  const layers = useMemo<AvatarLayer[]>(
    () =>
      SLOT_ORDER.map((slot) => ({
        slot,
        item:
          equippedItems.find(
            (item) => item.slot === slot
          ) ?? null,
      })),
    [equippedItems]
  );

  const topItem =
    layers.find((x) => x.slot === "top")?.item ?? null;

  const bottomItem =
    layers.find((x) => x.slot === "bottom")?.item ?? null;

  const socksItem = layers.find((x) => x.slot === "socks")?.item ?? null;

  const bootsItem =
    layers.find((x) => x.slot === "boots")?.item ?? null;

  const accessoryItem =
    layers.find((x) => x.slot === "accessory")?.item ?? null;

  const shortSleeves = isShortSleeveTop(topItem);
  const baseImage = appearance
    ? `/images/avatar-skin-${appearance.skin.replace("#", "").toLowerCase()}${shortSleeves ? "-short" : ""}.png`
    : shortSleeves ? "/images/avatar-base-short.png" : "/images/avatar-base.png";

  const avatarColor =
    topItem?.color ??
    bottomItem?.color ??
    bootsItem?.color ??
    "#00ff87";

  const avatarAura = hexToRgba(
    avatarColor,
    0.22
  );

  const avatarAuraSoft = hexToRgba(
    avatarColor,
    0.08
  );

  const visual = useMemo(() => Object.fromEntries(SLOT_ORDER.map(slot => [slot, getItemVisual(slot, layers.find(layer => layer.slot === slot)?.item ?? null)])), [layers]);

  return (
    <div
      className={[
        "avatar2d",
        compact ? "avatar2d--compact" : "",
      ]
        .filter(Boolean)
        .join(" ")}
      style={
        {
          "--avatar-color": avatarColor,
          "--avatar-aura": avatarAura,
          "--avatar-aura-soft": avatarAuraSoft,
        } as React.CSSProperties
      }
    >
      <div className="avatar2d__aura" />
      <div className="avatar2d__shadow" />

      <div className="avatar2d__character" data-avatar-rig="v2">

        {/* =========================
            BASE CHARACTER (PNG REAL)
        ========================= */}
        <img
          src={baseImage}
          alt="Avatar Base"
          className="avatar2d__base-image"
          onError={(event) => {
            const img = event.currentTarget;
            // No reemplazar una piel elegida por una base de otro color.
            // Registrar el recurso faltante para corregir public/images.
            console.error("Lupi World: sprite de piel no encontrado", img.src);
          }}
          draggable={false}
        />

        {appearance ? (
          <div className="avatar2d__custom-head"><AvatarFace appearance={mood === "miss" ? { ...appearance, expression: "sad" } : appearance} mood={mood && mood !== "miss" ? mood : undefined} className="lw-face--game" /></div>
        ) : (
          <img src="/images/head.png" className="avatar2d__base-head" alt="Cabeza del personaje" draggable={false} />
        )}


        {/* =========================
            CLOTHING LAYERS
        ========================= */}

        {topItem?.imageUrl && (
          <div className="avatar2d__layer avatar2d__layer--top" style={visual["top"]}>
            <AvatarItemImage
              item={topItem}
              className="avatar2d__image"
            />
          </div>
        )}

        {bottomItem?.imageUrl && (
          <div className="avatar2d__layer avatar2d__layer--bottom" style={visual["bottom"]}>
            <AvatarItemImage
              item={bottomItem}
              className="avatar2d__image"
            />
          </div>
        )}

        {socksItem?.imageUrl && (
          <div className="avatar2d__layer avatar2d__layer--socks" style={visual["socks"]}>
            <AvatarItemImage item={socksItem} className="avatar2d__image" />
          </div>
        )}

        {bootsItem?.imageUrl && (
  <div className="avatar2d__layer avatar2d__layer--boots" style={visual["boots"]}>
    <AvatarItemImage
      item={bootsItem}
      className="avatar2d__image"
    />
  </div>
)}

        {accessoryItem?.imageUrl && (
          <div className="avatar2d__layer avatar2d__layer--accessory" style={visual["accessory"]}>
            <AvatarItemImage
              item={accessoryItem}
              className="avatar2d__image"
            />
          </div>
        )}

        {!accessoryItem?.imageUrl && accessoryItem && (
          <div className="avatar2d__accessory-fallback">
            {SLOT_ICONS.accessory}
          </div>
        )}

      </div>
    </div>
  );
}
